﻿namespace Kata.CustomTypes.MenuFactoryRecursive
{
    public class DrinkMenuItem : MenuItemBase
    {

    }
}
