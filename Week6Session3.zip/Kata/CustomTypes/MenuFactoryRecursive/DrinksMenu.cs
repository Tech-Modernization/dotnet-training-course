﻿namespace Kata.CustomTypes.MenuFactoryRecursive
{
    public class DrinksMenu : MenuBase
    {
        protected override void CreateMenuItems()
        {
  
        }
    }
}
