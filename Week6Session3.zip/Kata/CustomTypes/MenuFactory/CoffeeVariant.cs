﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Kata.CustomTypes.MenuFactory
{
    public enum CoffeeVariant
    {
        Cappuccino,
        Mocha,
        Latte,
        Americano,
        Espresso
    }
}
