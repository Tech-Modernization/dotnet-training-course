﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Kata.CustomTypes.MenuFactoryRecursive
{
    public enum CoffeeVariant
    {
        Cappuccino,
        Mocha,
        Latte,
        Americano,
        Espresso
    }
}
