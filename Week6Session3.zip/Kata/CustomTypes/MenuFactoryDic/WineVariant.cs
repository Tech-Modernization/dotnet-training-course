﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Kata.CustomTypes.MenuFactoryRecursive
{
    public enum WineVariant
    {
        Bordeaux,
        Cabernet,
        Grenache,
        Merlot,
        Shiraz,
        Zinfandel,
        CheninBlanc,
        PinotGrigio,
        Rioja
    }
}
