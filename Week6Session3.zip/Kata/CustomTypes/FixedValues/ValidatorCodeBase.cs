﻿namespace Kata.CustomTypes.FixedValues
{
    public enum ValidatorCodeBase { }
}