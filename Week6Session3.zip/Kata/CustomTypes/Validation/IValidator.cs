﻿namespace Kata.CustomTypes.Validation
{
    public interface IValidator
    {
    }
}
