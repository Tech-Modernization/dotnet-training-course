﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Kata.CustomTypes.DrinkFactory
{
    public class CoffeeVariant : DrinkVariantBase
    {
    }
}
