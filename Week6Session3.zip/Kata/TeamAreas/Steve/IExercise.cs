﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DemoKata.Exercises
{
    public interface IExercise
    {
        public void Run();
    }
}
