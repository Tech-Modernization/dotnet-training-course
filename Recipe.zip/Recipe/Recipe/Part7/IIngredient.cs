﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Recipe.Part7
{
    public interface IIngredient
    {
        void Prepare();
    }
}
