﻿using System;

namespace Recipe
{
    public class Program
    {
        static void Main(string[] args)
        {
            var wrapper = new RecipeDemo();
            wrapper.Run();
        }
    }
}
