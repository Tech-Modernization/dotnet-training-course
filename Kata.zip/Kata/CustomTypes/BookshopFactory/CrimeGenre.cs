﻿
namespace Kata.CustomTypes.BookshopFactory
{
    public class CrimeGenre : GenreBase
    {
    }
}
