﻿
namespace Kata.CustomTypes.BookshopFactory
{
    public abstract class GenreBase
    {
    }
}
