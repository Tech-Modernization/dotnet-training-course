﻿namespace Kata.CustomTypes.BookshopFactory
{
    public class SciFiGenre : GenreBase
    {
    }
}
