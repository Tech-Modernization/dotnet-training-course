﻿namespace Kata.CustomTypes.BookshopFactory
{
    public class TrueCrimeGenre : GenreBase
    {
    }
}
