﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Kata.CustomTypes.MenuItemVariantFactory
{
    public class DrinkMenuItemVariant : MenuItemVariantBase
    {
    }
}
