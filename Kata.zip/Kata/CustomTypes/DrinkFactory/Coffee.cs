﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Kata.CustomTypes.DrinkFactory
{
    public class Coffee : DrinkBase
    {
        protected override void CreateVariants()
        {
            throw new NotImplementedException();
        }
    }
}
