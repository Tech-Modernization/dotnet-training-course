﻿namespace Kata.CustomTypes.Validation
{
    public class NumberValidator : ValidatorBase<int>
    {
        public override bool IsValid(int arg)
        {
            throw new System.NotImplementedException();
        }
    }
}
