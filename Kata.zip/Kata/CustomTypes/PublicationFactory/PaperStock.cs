﻿namespace Kata.CustomTypes.PublicationFactory
{
    public enum PaperStock
    {
        A3,
        A4,
        A5,
        A6,
        B4,
        B5,
        B6
    }
}
