﻿namespace Kata.CustomTypes.PublicationFactory
{
    public enum PaperFinish
    {
        Recycled,
        Matt,
        Gloss
    }
}
