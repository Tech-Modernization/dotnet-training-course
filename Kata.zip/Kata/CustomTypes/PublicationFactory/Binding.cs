﻿namespace Kata.CustomTypes.PublicationFactory
{
    public enum Binding
    {
        Gum,
        Cord,
        Staple,
        Spiral
    }
}
