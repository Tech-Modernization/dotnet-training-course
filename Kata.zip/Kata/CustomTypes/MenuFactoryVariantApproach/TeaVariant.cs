﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Kata.CustomTypes.MenuFactoryVariant
{
    public enum TeaVariant
    {
        EarlGrey,
        CinnamonSpicedApple,
        Camomile,
        LemonGinger,
        Breakfast,
        Green,
        Lemon
    }
}
