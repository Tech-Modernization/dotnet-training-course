﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Kata.CustomTypes.MenuFactoryRecursive
{
    public enum TeaVariant
    {
        EarlGrey,
        CinnamonSpicedApple,
        Camomile,
        LemonGinger,
        Breakfast,
        Green,
        Lemon
    }
}
