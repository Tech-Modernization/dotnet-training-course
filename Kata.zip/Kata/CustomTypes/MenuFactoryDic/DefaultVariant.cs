﻿namespace Kata.CustomTypes.MenuFactoryDic
{
    public enum DefaultVariant
    {
        Default
    }
}