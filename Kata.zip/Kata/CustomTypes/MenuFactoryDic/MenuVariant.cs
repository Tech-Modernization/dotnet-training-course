﻿namespace Kata.CustomTypes.MenuFactoryDic
{
    public enum MenuVariant
    {
        Default
    }
}
