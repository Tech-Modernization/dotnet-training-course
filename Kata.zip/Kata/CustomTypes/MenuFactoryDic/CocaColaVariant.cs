﻿

namespace Kata.CustomTypes.MenuFactoryDic
{
    public enum CocaColaVariant
    {
        Classic,
        Diet,
        Cherry,
        Vanilla,
        Ginger,
        Orange
    }
}
