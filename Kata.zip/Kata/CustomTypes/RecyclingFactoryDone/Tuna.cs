﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Kata.CustomTypes.RecyclingFactoryDone
{
    public class Tuna : TinBase
    {
    }
}
