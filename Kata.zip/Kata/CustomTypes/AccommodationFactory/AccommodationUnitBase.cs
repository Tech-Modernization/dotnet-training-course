﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Kata.CustomTypes.AccommodationFactory
{
    // abstract product
    public abstract class AccommodationUnitBase
    {
    }
}
