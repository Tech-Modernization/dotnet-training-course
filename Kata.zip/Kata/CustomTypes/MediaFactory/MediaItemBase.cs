﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Kata.CustomTypes.MediaFactory
{
    // Product role in Factory pattern...
    public abstract class MediaItemBase
    {
    }
}
