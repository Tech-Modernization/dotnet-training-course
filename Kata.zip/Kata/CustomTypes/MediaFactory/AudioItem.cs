﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Kata.CustomTypes.MediaFactory
{
    // Concrete Product role
    public class AudioItem : MediaItemBase
    {
    }
}
