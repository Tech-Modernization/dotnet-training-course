﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Kata.CustomTypes.FestivalFactory
{
    public enum Genre
    {
        Jazz,
        Folk,
        ProgRock,
        Indie
    }
}
