﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Kata.CustomTypes.FestivalFactory
{
    public class JazzAct : ActBase
    {
    }
}
