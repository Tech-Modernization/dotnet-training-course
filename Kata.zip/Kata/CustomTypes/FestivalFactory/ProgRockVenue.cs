﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Kata.CustomTypes.FestivalFactory
{
    public class ProgRockVenue : VenueBase
    {
        protected override void CreateActs()
        {
        }
    }
}
