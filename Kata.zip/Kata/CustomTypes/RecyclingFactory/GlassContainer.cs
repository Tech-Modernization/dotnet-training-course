﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Kata.CustomTypes.RecyclingFactory
{
    public class GlassContainer : ContainerBase
    {
        protected override void CreateMaterials()
        {
        }
    }
}
