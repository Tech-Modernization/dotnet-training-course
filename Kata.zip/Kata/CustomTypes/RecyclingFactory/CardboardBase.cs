﻿using System;
using System.Collections.Generic;
using System.Text;

namespace  Kata.CustomTypes.RecyclingFactory
{
    public class CardboardBase : MaterialBase
    {
        public CardboardBase(string name) : base(name)
        {
        }
    }
}
