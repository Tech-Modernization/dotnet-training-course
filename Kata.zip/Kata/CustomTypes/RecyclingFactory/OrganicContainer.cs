﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Kata.CustomTypes.RecyclingFactory
{
    public class OrganicContainer : ContainerBase
    {
        protected override void CreateMaterials()
        {
        }
    }
}
