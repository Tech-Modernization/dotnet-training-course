﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Kata.CustomTypes.RecyclingFactory
{
    public class PaperContainer : ContainerBase
    {
        protected override void CreateMaterials()
        {
            
        }
    }
}
