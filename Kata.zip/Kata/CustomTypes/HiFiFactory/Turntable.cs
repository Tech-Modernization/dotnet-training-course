﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Kata.CustomTypes.HiFiFactory
{
    public class Turntable : ComponentBase
    {
    }
}
