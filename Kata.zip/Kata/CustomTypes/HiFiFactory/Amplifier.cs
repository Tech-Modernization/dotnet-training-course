﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Kata.CustomTypes.HiFiFactory
{
    public class Amplifier : ComponentBase
    {
    }
}
