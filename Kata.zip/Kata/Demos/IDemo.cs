﻿namespace Kata.Demos
{
    public interface IDemo
    {
        void Run();
    }
}
