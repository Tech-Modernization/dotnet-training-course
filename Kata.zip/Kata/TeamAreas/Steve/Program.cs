﻿using DemoKata.Exercises;
using System;

namespace DemoKata
{
    class Program
    {
        static void Main(string[] args)
        {
            //var ex16 = new DrinksOrder();
            //ex16.Run();

            (new DrinksOrder_SH()).Run();




        }
    }
}
