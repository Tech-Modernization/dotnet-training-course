﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Recipe.Part3
{
    public interface IIngredient
    {
        void Prepare();
    }
}
