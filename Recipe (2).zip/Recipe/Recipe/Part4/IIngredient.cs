﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Recipe.Part4
{
    public interface IIngredient
    {
        void Prepare();
    }
}
