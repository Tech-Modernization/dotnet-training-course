﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Recipe.Part5
{
    public interface IIngredient
    {
        void Prepare();
    }
}
